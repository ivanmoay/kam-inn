@props(['submit_txt'])
<div class="text-center">
    <button type="submit" class="btn btn-primary">{{$submit_txt}}</button>
    <button type="reset" class="btn btn-secondary">Reset</button>
</div>