Sale Recorded <br />
Date and Time: {{Carbon\Carbon::parse($date_time)->format('d/m/Y g:i a')}} <br />
Total: {{$total}} <br />
by: {{$user}}